"""
Test initialization file
"""
